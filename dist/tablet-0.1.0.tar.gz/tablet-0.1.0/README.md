# Tablet

Welcome to the TABLET paper repo! Let's use natural language instructions (and maybe a few examples) to try and solve tabular prediction tasks with LLMs.

### Overview

TABLET is a dataset containing tabular classification problems (i.e., rows and columns data) 


### Why?
